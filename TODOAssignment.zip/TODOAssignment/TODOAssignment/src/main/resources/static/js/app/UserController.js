'use strict';

angular.module('crudApp').controller('UserController',
    ['UserService', '$scope',  function( UserService, $scope) {

        var self = this;
        self.User = {};
        self.Users=[];

        self.submit = submit;
        self.getAllUsers = getAllUsers;
        self.createUser = createUser;
        self.updateUser = updateUser;
        self.removeUser = removeUser;
        self.editUser = editUser;
        self.reset = reset;

        self.successMessage = '';
        self.errorMessage = '';
        self.done = false;

        self.onlyIntegers = /^\d+$/;
        self.onlyNumbers = /^\d+([,.]\d+)?$/;

        function submit() {
            console.log('Submitting');
            if (self.User.id === undefined || self.User.id === null) {
                console.log('Saving New Activity', self.User);
                createUser(self.User);
            } else {
                updateUser(self.User, self.User.id);
                console.log('Activity updated with id ', self.User.id);
            }
        }

        function createUser(User) {
            console.log('About to create activity');
            UserService.createUser(User)
                .then(
                    function (response) {
                        console.log('Activity/Task created successfully');
                        self.successMessage = 'Activity/Task successfully';
                        self.errorMessage='';
                        self.done = true;
                        self.User={};
                        $scope.myForm.$setPristine();
                    },
                    function (errResponse) {
                        console.error('Error while creating activity');
                        self.errorMessage = 'Error while creating activity: ' + errResponse.data.errorMessage;
                        self.successMessage='';
                    }
                );
        }


        function updateUser(User, id){
            console.log('About to update activity');
            UserService.updateUser(User, id)
                .then(
                    function (response){
                        console.log('Activity/Task updated successfully');
                        self.successMessage='Activity/Task updated successfully';
                        self.errorMessage='';
                        self.done = true;
                        $scope.myForm.$setPristine();
                    },
                    function(errResponse){
                        console.error('Error while updating User');
                        self.errorMessage='Error while updating activity '+errResponse.data;
                        self.successMessage='';
                    }
                );
        }

     
        
        function removeUser(id){
            console.log('About to remove Activity with id '+id);
            UserService.removeUser(id)
                .then(
                    function(){
                        console.log('Activity '+id + ' removed successfully');
                    },
                    function(errResponse){
                        console.error('Error while removing an activity '+id +', Error :'+errResponse.data);
                    }
                );
        }


        function getAllUsers(){
            return UserService.getAllUsers();
        }

        function editUser(id) {
            self.successMessage='';
            self.errorMessage='';
            UserService.getUser(id).then(
                function (User) {
                    self.User = User;
                },
                function (errResponse) {
                    console.error('Error while removing activity ' + id + ', Error :' + errResponse.data);
                }
            );
        }
        function reset(){
            self.successMessage='';
            self.errorMessage='';
            self.User={};
            $scope.myForm.$setPristine(); //reset Form
        }
    }
    
   


    ]);