/*============================================================================*/
/**Title 		:    UserService.java
 * Description	:    This is interface of the service class.
 * 					 
 * Copyright 	:    Copyright (c) 2017
 * Company 		:    Emirates
 *
 * Revision History
 * ----------------
 *
 * Date				Author		Description
 * -----------		---------	----------------------------------
 * Oct 26, 2017		Sadhika		Initial Creation of TODO Assignment
 */
/*============================================================================*/
/*============================================================================*/
/*                             Package Definition                             */
/*============================================================================*/
package com.todo.springboot.service;

/*============================================================================*/
/*                                  Imports                                   */
/*============================================================================*/
import com.todo.springboot.model.User;

import java.util.List;

public interface UserService {

	User findById(Long id);

	User findByName(String name);

	void saveUser(User User);

	void updateUser(User User);

	void deleteUserById(Long id);

	void deleteAllUsers();

	List<User> findAllUsers();

	boolean isUserExist(User User);
}