/*============================================================================*/
/**Title 		:    CustomErrorType.java
 * Description	:    This is the helper class to send errors [in-case any] from API in JSON format iso string.
 * 					 
 * Copyright 	:    Copyright (c) 2017
 * Company 		:    Emirates
 *
 * Revision History
 * ----------------
 *
 * Date				Author		Description
 * -----------		---------	----------------------------------
 * Oct 26, 2017		Sadhika		Initial Creation of TODO Assignment
 */
/*============================================================================*/
/*============================================================================*/
/*                             Package Definition                             */
/*============================================================================*/

package com.todo.springboot.util;


public class CustomErrorType {

	private String errorMessage;

	public CustomErrorType(String errorMessage){
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
