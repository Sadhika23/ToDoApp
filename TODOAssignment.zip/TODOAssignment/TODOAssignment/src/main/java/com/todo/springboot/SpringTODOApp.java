/*============================================================================*/
/**Title 		:    SpringTODOApp.java
 * Description	:    This is the main class to start our newly created spring boot TODO App.
 * 					 
 * Copyright 	:    Copyright (c) 2017
 * Company 		:    Emirates
 *
 * Revision History
 * ----------------
 *
 * Date				Author		Description
 * -----------		---------	----------------------------------
 * Oct 26, 2017		Sadhika		Initial Creation of TODO Assignment
 */
/*============================================================================*/
/*============================================================================*/
/*                             Package Definition                             */
/*============================================================================*/
package com.todo.springboot;

/*============================================================================*/
/*                                  Imports                                   */
/*============================================================================*/
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.todo.springboot.configuration.JpaConfiguration;


@Import(JpaConfiguration.class)
@SpringBootApplication(scanBasePackages={"com.todo.springboot"})// same as @Configuration @EnableAutoConfiguration @ComponentScan
public class SpringTODOApp {

	//Spring Boot provides SpringApplication class to bootstrap a Spring application that will be started from a main() method using static SpringApplication.run method.

	public static void main(String[] args) {
		SpringApplication.run(SpringTODOApp.class, args);
	}
}
