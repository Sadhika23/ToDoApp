/*============================================================================*/
/**Title 		:    User.java
 * Description	:    This class is the model class which has activity entities of the user
 * 					 
 * Copyright 	:    Copyright (c) 2017
 * Company 		:    Emirates
 *
 * Revision History
 * ----------------
 *
 * Date				Author		Description
 * -----------		---------	----------------------------------
 * Oct 26, 2017		Sadhika		Initial Creation of TODO Assignment
 */
/*============================================================================*/
/*============================================================================*/
/*                             Package Definition                             */
/*============================================================================*/

package com.todo.springboot.model;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="APP_TODO_LI")
public class User implements Serializable{

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;

	@NotEmpty
	@Column(name="NAME", nullable=false)
	private String name;

	@Column(name="status", nullable=false)
	private String status;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getstatus() {
		return status;
	}

	public void setstatus(String status) {
		this.status = status;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		User User = (User) o;

		if (status != null ? !status.equals(User.status) : User.status != null) return false;
		if (id != null ? !id.equals(User.id) : User.id != null) return false;
		if (name != null ? !name.equals(User.name) : User.name != null) return false;
		return false;

	}

	@Override
	public int hashCode() {
		int result;
		long temp;
		result = id != null ? id.hashCode() : 0;
		result = 31 * result + (name != null ? name.hashCode() : 0);
		temp = 31 * result + (status != null ? status.hashCode() : 0);
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", status=" + status +"]";
	}

}


