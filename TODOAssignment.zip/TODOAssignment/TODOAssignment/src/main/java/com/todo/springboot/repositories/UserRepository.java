/*============================================================================*/
/**Title 		:    UserRepository.java
 * Description	:    This Interface class provides all the CRUD operations by-default using id as the key
 * 					 
 * Copyright 	:    Copyright (c) 2017
 * Company 		:    Emirates
 *
 * Revision History
 * ----------------
 *
 * Date				Author		Description
 * -----------		---------	----------------------------------
 * Oct 26, 2017		Sadhika		Initial Creation of TODO Assignment
 */
/*============================================================================*/
/*============================================================================*/
/*                             Package Definition                             */
/*============================================================================*/
package com.todo.springboot.repositories;

/*============================================================================*/
/*                                  Imports                                   */
/*============================================================================*/
import com.todo.springboot.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	User findByName(String name);

}
