/*============================================================================*/
/**Title 		:    RestApiController.java
 * Description	:    This class handles the REST API calls, coming from Our AngularJS based Front-end.
 * 					 
 * Copyright 	:    Copyright (c) 2017
 * Company 		:    Emirates
 *
 * Revision History
 * ----------------
 *
 * Date				Author		Description
 * -----------		---------	----------------------------------
 * Oct 26, 2017		Sadhika		Initial Creation of TODO Assignment
 */
/*============================================================================*/
/*============================================================================*/
/*                             Package Definition                             */
/*============================================================================*/
package com.todo.springboot.controller;

import java.util.List;

/*============================================================================*/
/*                                  Imports                                   */
/*============================================================================*/
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.todo.springboot.model.User;
import com.todo.springboot.service.UserService;
import com.todo.springboot.util.CustomErrorType;


/*============================================================================*/
/*                     Class Definition / Implementation                      */
/*============================================================================*/

/*============================================================================*/

@RestController
@RequestMapping("/api")
public class RestApiController {

	public static final Logger logger = LoggerFactory.getLogger(RestApiController.class);

	@Autowired
	UserService UserService; //Service which will do all data retrieval/manipulation work

	// -------------------Retrieve All Activities of the user---------------------------------------------

	@RequestMapping(value = "/User/", method = RequestMethod.GET)
	public ResponseEntity<List<User>> listAllUsers() {
		List<User> Users = UserService.findAllUsers();
		if (Users.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
			// You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<User>>(Users, HttpStatus.OK);
	}

	// -------------------Retrieve Single Activity of the User------------------------------------------

	@RequestMapping(value = "/User/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getUser(@PathVariable("id") long id) {
		logger.info("Fetching Activity with id {}", id);
		User User = UserService.findById(id);
		if (User == null) {
			logger.error("Activity with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("Activity with id " + id 
					+ " not found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<User>(User, HttpStatus.OK);
	}

	// -------------------Create a Activity for the user-------------------------------------------

	@RequestMapping(value = "/User/", method = RequestMethod.POST)
	public ResponseEntity<?> createUser(@RequestBody User User, UriComponentsBuilder ucBuilder) {
		logger.info("Creating Activity : {}", User);

		if (UserService.isUserExist(User)) {
			logger.error("Unable to create an activity/task with name {} already exist", User.getName());
			return new ResponseEntity(new CustomErrorType("Unable to create. A activity/task with name " + 
					User.getName() + " already exist."),HttpStatus.CONFLICT);
		}
		UserService.saveUser(User);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/api/User/{id}").buildAndExpand(User.getId()).toUri());
		return new ResponseEntity<String>(headers, HttpStatus.CREATED);
	}

	// ------------------- Update an activity of the User ------------------------------------------------

	@RequestMapping(value = "/User/{id}", method = RequestMethod.PUT)
	public ResponseEntity<?> updateUser(@PathVariable("id") long id, @RequestBody User User) {
		logger.info("Updating Activity/Task with id {}", id);

		User currentUser = UserService.findById(id);

		if (currentUser == null) {
			logger.error("Unable to update an activity/task with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("Unable to upate. Activity/Task with id " + id + " not found."),
					HttpStatus.NOT_FOUND);
		}
		if(User.getstatus().equalsIgnoreCase("Pending") &&  User.getName().equalsIgnoreCase(currentUser.getName()))
		{
			currentUser.setstatus("Completed");
		}
		else
		{
			currentUser.setstatus(User.getstatus());
		}
		currentUser.setName(User.getName());


		UserService.updateUser(currentUser);
		return new ResponseEntity<User>(currentUser, HttpStatus.OK);
	}

	// ------------------- Delete an activity of the User-----------------------------------------

	@RequestMapping(value = "/User/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteUser(@PathVariable("id") long id) {
		logger.info("Fetching & Deleting Activity with id {}", id);

		User User = UserService.findById(id);
		if (User == null) {
			logger.error("Unable to delete an Activity/Task with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("Unable to delete. Activity/Task with id " + id + " not found."),
					HttpStatus.NOT_FOUND);
		}
		UserService.deleteUserById(id);
		return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
	}

	// ------------------- Delete All User activities-----------------------------

	@RequestMapping(value = "/User/", method = RequestMethod.DELETE)
	public ResponseEntity<User> deleteAllUsers() {
		logger.info("Deleting All Activity/Task");

		UserService.deleteAllUsers();
		return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
	}

}